package com.brightleaf.mongoservice.service;

import org.json.JSONObject;

public interface IgnoreResultService {

	String ignoreResult(String companyName, JSONObject jsonObject);

}
