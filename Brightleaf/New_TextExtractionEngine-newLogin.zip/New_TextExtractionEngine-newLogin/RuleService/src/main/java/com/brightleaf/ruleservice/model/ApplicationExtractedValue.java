package com.brightleaf.ruleservice.model;

public class ApplicationExtractedValue {
	private String initialValue;
	private String valueAddedBy;
	
	public String getInitialValue() {
		return initialValue;
	}
	public void setInitialValue(String initialValue) {
		this.initialValue = initialValue;
	}
	public String getValueAddedBy() {
		return valueAddedBy;
	}
	public void setValueAddedBy(String valueAddedBy) {
		this.valueAddedBy = valueAddedBy;
	}
}
