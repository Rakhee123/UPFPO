package com.brightleaf.ruleservice.model;

import java.util.List;

public class DocList {

	List<String> documentList;

}
