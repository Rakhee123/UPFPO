package com.brightleaf.exportservice.model;

public class AttributeConsolidated {

	private String attributeName;
	private String applicationExtractedValue;
	
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	public String getApplicationExtractedValue() {
		return applicationExtractedValue;
	}
	public void setApplicationExtractedValue(String applicationExtractedValue) {
		this.applicationExtractedValue = applicationExtractedValue;
	}
}