import { ResultconsolidatedDirective } from './resultconsolidated.directive';

describe('ResultconsolidatedDirective', () => {
  it('should create an instance', () => {
    const directive = new ResultconsolidatedDirective();
    expect(directive).toBeTruthy();
  });
});
