import { AlphabetsOnlyDirective } from './alphabets-only.directive';

describe('AlphabetsOnlyDirective', () => {
  it('should create an instance', () => {
    const directive = new AlphabetsOnlyDirective();
    expect(directive).toBeTruthy();
  });
});
