import { Component } from '@angular/core';
@Component({
  selector: 'app-to-do',
  templateUrl: './todo.component.html'
})
export class TodoComponent {
  constructor() {}
}
