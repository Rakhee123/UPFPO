import { Component } from '@angular/core';
@Component({
  selector: 'app-widget',
  templateUrl: './widget.component.html'
})
export class WidgetComponent {
  constructor() {}
}
