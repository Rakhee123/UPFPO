import { Component } from '@angular/core';
@Component({
  selector: 'app-profile-box',
  templateUrl: './profile.component.html'
})
export class ProfileComponent {
  constructor() {}
}
