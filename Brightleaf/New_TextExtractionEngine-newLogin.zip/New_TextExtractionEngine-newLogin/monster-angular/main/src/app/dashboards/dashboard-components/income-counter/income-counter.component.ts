import { Component } from '@angular/core';
@Component({
  selector: 'app-income-counter',
  templateUrl: './income-counter.component.html'
})
export class IncomeCounterComponent {
  constructor() {}
}
