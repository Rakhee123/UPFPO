import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addconfigure',
  templateUrl: './addconfigure.component.html',
  styleUrls: ['./addconfigure.component.css']
})
export class AddconfigureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  saveDocument()
  {
    
  }

}
